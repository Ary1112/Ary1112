class AppVariables{
    //static readonly ApiUrl:string = "https://localhost:7133";
    static readonly ApiUrl:string = "https://www.rayanestaszewski.fr";
}

export default AppVariables;